package com.SpringAlphaProject.AlphaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
